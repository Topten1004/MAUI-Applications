﻿namespace MauiSampleLogin.Models.Restaurant
{
    public class RestaurantResponse
    {
        public int id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public int rating { get; set; }
        public string image { get; set; }
    }
}
