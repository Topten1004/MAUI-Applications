﻿namespace MauiSampleLogin.Helper
{
    public class Constants
    {
        public static string BASE_URL = "http://192.168.1.109:8080";
    }
}
