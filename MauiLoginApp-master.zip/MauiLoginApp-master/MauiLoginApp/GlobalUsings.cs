﻿global using Microsoft.Toolkit.Mvvm.ComponentModel;
global using Microsoft.Toolkit.Mvvm.Input;
global using MauiLoginApp.Models;
global using System.Net.Http.Json;
global using MauiLoginApp.Repository;
global using Newtonsoft.Json;
global using MauiLoginApp.Views;
global using MauiLoginApp.ViewModels;
global using MauiLoginApp.UserControl;

