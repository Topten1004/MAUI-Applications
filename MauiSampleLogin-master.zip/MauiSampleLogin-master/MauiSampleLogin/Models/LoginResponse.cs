﻿namespace MauiSampleLogin.Models
{
    public class LoginResponse
    {
        public string Access_Token { get; set; }
        public string Refresh_Token { get; set; }
    }
}
